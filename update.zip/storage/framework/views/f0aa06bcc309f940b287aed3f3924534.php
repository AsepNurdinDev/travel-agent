<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['booking']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['booking']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="card p-6">
    <h3 class="font-bold text-ink">Rincian Harga</h3>
    <div class="mt-4 space-y-2 text-sm">
        <div class="flex justify-between"><span class="text-muted">Dewasa × <?php echo e($booking->adult_count); ?></span><span>Rp <?php echo e(number_format($booking->price_adult * $booking->adult_count, 0, ',', '.')); ?></span></div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->child_count > 0): ?>
            <div class="flex justify-between"><span class="text-muted">Anak-anak × <?php echo e($booking->child_count); ?></span><span>Rp <?php echo e(number_format($booking->price_child * $booking->child_count, 0, ',', '.')); ?></span></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->infant_count > 0): ?>
            <div class="flex justify-between"><span class="text-muted">Bayi × <?php echo e($booking->infant_count); ?></span><span>Rp <?php echo e(number_format($booking->price_infant * $booking->infant_count, 0, ',', '.')); ?></span></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->addons_total > 0): ?>
            <div class="flex justify-between"><span class="text-muted">Add-ons</span><span>Rp <?php echo e(number_format($booking->addons_total, 0, ',', '.')); ?></span></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <div class="flex justify-between border-t border-slate-100 pt-2"><span class="text-muted">Subtotal</span><span>Rp <?php echo e(number_format($booking->subtotal, 0, ',', '.')); ?></span></div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->discount_amount > 0): ?>
            <div class="flex justify-between text-emerald-600"><span>Discount<?php echo e($booking->promotion ? ' ('.$booking->promotion->code.')' : ''); ?></span><span>- Rp <?php echo e(number_format($booking->discount_amount, 0, ',', '.')); ?></span></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <div class="flex justify-between border-t border-slate-100 pt-3 text-base font-bold text-ink">
            <span>Total</span><span>Rp <?php echo e(number_format($booking->total_amount, 0, ',', '.')); ?></span>
        </div>
        <div class="flex justify-between text-emerald-600"><span>Sudah Dibayar</span><span>Rp <?php echo e(number_format($booking->amount_paid, 0, ',', '.')); ?></span></div>
        <div class="flex justify-between font-semibold text-ink"><span>Balance Due</span><span>Rp <?php echo e(number_format($booking->balance_due, 0, ',', '.')); ?></span></div>
    </div>
</div>
<?php /**PATH /home/asepnrdn/projects/clients/travels/travel-agent/resources/views/components/price-breakdown.blade.php ENDPATH**/ ?>