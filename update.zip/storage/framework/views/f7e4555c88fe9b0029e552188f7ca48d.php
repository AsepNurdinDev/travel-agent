<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/asepnrdn/projects/clients/travels/travel-agent/vendor/filament/widgets/resources/views/components/widget.blade.php ENDPATH**/ ?>