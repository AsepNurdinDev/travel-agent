<footer class="border-t border-slate-100 bg-ink text-slate-300">
    <div class="container-page py-14 grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4">
        <div>
            <div class="flex items-center gap-2">
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-white font-bold">N</span>
                <span class="text-lg font-bold text-white"><?php echo e(\App\Models\Setting::getValue('site_name', 'Nusantara Journeys')); ?></span>
            </div>
            <p class="mt-4 text-sm leading-relaxed text-slate-400">
                <?php echo e(\App\Models\Setting::getValue('site_tagline', 'Thoughtfully planned tours across Indonesia\'s islands, reefs and highlands — handled by a team that knows the way.')); ?>

            </p>
            <div class="mt-5 flex gap-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['Instagram','Facebook','TikTok']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <span class="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 text-xs"><?php echo e(substr($s,0,1)); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>

        <div>
            <h4 class="text-sm font-semibold uppercase tracking-wider text-white">Jelajahi</h4>
            <ul class="mt-4 space-y-2.5 text-sm">
                <li><a href="<?php echo e(route('destinations.index')); ?>" class="hover:text-primary-200">Destinasi</a></li>
                <li><a href="<?php echo e(route('tours.index')); ?>" class="hover:text-primary-200">Paket Wisata</a></li>
                <li><a href="<?php echo e(route('blog.index')); ?>" class="hover:text-primary-200">Blog Perjalanan</a></li>
                <li><a href="<?php echo e(route('gallery.index')); ?>" class="hover:text-primary-200">Galeri</a></li>
            </ul>
        </div>

        <div>
            <h4 class="text-sm font-semibold uppercase tracking-wider text-white">Company</h4>
            <ul class="mt-4 space-y-2.5 text-sm">
                <li><a href="<?php echo e(route('about')); ?>" class="hover:text-primary-200">Tentang Kami</a></li>
                <li><a href="<?php echo e(route('contact.index')); ?>" class="hover:text-primary-200">Kontak</a></li>
                <li><a href="<?php echo e(route('login')); ?>" class="hover:text-primary-200">Masuk</a></li>
                <li><a href="<?php echo e(route('register')); ?>" class="hover:text-primary-200">Buat Akun</a></li>
            </ul>
        </div>

        <div>
            <h4 class="text-sm font-semibold uppercase tracking-wider text-white">Kontak</h4>
            <ul class="mt-4 space-y-2.5 text-sm text-slate-400">
                <li><?php echo e(\App\Models\Setting::getValue('contact_address', 'Jl. Merdeka No. 1, Bandung, Indonesia')); ?></li>
                <li><?php echo e(\App\Models\Setting::getValue('contact_phone', '+62 21 555 0123')); ?></li>
                <li><?php echo e(\App\Models\Setting::getValue('contact_email', 'hello@nusantarajourneys.test')); ?></li>
            </ul>
        </div>
    </div>

    <div class="border-t border-white/10">
        <div class="container-page py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
            <p>&copy; <?php echo e(now()->year); ?> <?php echo e(\App\Models\Setting::getValue('site_name', 'Nusantara Journeys')); ?>. Hak cipta dilindungi.</p>
            <div class="flex gap-4">
                <span>Kebijakan Privasi</span>
                <span>Syarat & Ketentuan</span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/asepnrdn/projects/clients/travels/travel-agent/resources/views/components/footer.blade.php ENDPATH**/ ?>