<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => ['title' => 'Detail Pesanan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Pesanan']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        
        
        <div>
            <a href="<?php echo e(route('account.bookings')); ?>" 
               class="inline-flex items-center gap-2 rounded-xl bg-slate-100 px-3.5 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 hover:text-slate-900 transition">
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
                </svg>
                <span>Kembali ke Pesanan Saya</span>
            </a>
        </div>

        
        <div class="rounded-3xl border border-slate-100 bg-white p-6 sm:p-8 shadow-sm space-y-6">
            
            
            <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-100 pb-6">
                <div class="space-y-1">
                    <span class="font-mono text-xs font-extrabold tracking-wider text-emerald-600 uppercase">
                        <?php echo e($booking->booking_code); ?>

                    </span>
                    <h1 class="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                        <?php echo e($booking->tourPackage->name); ?>

                    </h1>
                </div>
                <div class="self-start sm:self-auto">
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $booking->status,'class' => 'text-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($booking->status),'class' => 'text-sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                </div>
            </div>

            
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div class="rounded-2xl bg-slate-50 p-3.5 border border-slate-100/80">
                    <p class="text-slate-400 font-medium">Destinasi</p>
                    <p class="font-bold text-slate-900 text-sm mt-0.5 truncate">
                        <?php echo e($booking->tourPackage->destination->name ?? '—'); ?>

                    </p>
                </div>

                <div class="rounded-2xl bg-slate-50 p-3.5 border border-slate-100/80">
                    <p class="text-slate-400 font-medium">Keberangkatan</p>
                    <p class="font-bold text-slate-900 text-sm mt-0.5">
                        <?php echo e(optional($booking->availability)->departure_date?->format('d M Y') ?? '—'); ?>

                    </p>
                </div>

                <div class="rounded-2xl bg-slate-50 p-3.5 border border-slate-100/80">
                    <p class="text-slate-400 font-medium">Kepulangan</p>
                    <p class="font-bold text-slate-900 text-sm mt-0.5">
                        <?php echo e(optional($booking->availability)->return_date?->format('d M Y') ?? '—'); ?>

                    </p>
                </div>

                <div class="rounded-2xl bg-slate-50 p-3.5 border border-slate-100/80">
                    <p class="text-slate-400 font-medium">Tanggal Dipesan</p>
                    <p class="font-bold text-slate-900 text-sm mt-0.5">
                        <?php echo e($booking->created_at->format('d M Y')); ?>

                    </p>
                </div>
            </div>

            
            <div class="border-t border-slate-100 pt-5 space-y-2">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700">Jumlah Peserta</h3>
                <div class="flex flex-wrap gap-2 text-xs">
                    <span class="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 px-3 py-1.5 font-medium text-slate-700">
                        <span>Dewasa:</span>
                        <strong class="text-slate-900 font-extrabold"><?php echo e($booking->adult_count); ?></strong>
                    </span>
                    <span class="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 px-3 py-1.5 font-medium text-slate-700">
                        <span>Anak-anak:</span>
                        <strong class="text-slate-900 font-extrabold"><?php echo e($booking->child_count); ?></strong>
                    </span>
                    <span class="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 px-3 py-1.5 font-medium text-slate-700">
                        <span>Bayi:</span>
                        <strong class="text-slate-900 font-extrabold"><?php echo e($booking->infant_count); ?></strong>
                    </span>
                </div>
            </div>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->items->isNotEmpty()): ?>
                <div class="border-t border-slate-100 pt-5 space-y-2.5">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700">Layanan Tambahan (Add-ons)</h3>
                    <ul class="space-y-2 text-xs divide-y divide-slate-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $booking->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li class="flex items-center justify-between pt-2 first:pt-0 text-slate-600 font-medium">
                                <span><?php echo e($item->name); ?> <span class="text-slate-400 font-bold">&times; <?php echo e($item->quantity); ?></span></span>
                                <span class="font-bold text-slate-900">Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></span>
                            </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->notes): ?>
                <div class="border-t border-slate-100 pt-5 space-y-1.5">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700">Catatan Pesanan</h3>
                    <div class="rounded-2xl bg-slate-50 p-4 border border-slate-100 text-xs text-slate-600 leading-relaxed">
                        <?php echo e($booking->notes); ?>

                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!in_array($booking->status, ['cancelled', 'completed'])): ?>
                <div class="border-t border-slate-100 pt-5 flex flex-wrap items-center gap-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) $booking->balance_due > 0): ?>
                        <a href="<?php echo e(route('booking.checkout', $booking)); ?>" 
                           class="inline-flex items-center gap-2 rounded-xl bg-amber-500 px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-amber-600 transition">
                            <span>Bayar Sisa Pelunasan</span>
                            <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                            </svg>
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <form method="POST" 
                          action="<?php echo e(route('account.bookings.cancel', $booking)); ?>"
                          onsubmit="return confirm('Apakah Anda yakin ingin membatalkan pesanan ini? Tindakan ini tidak dapat dibatalkan.');">
                        <?php echo csrf_field(); ?>
                        <button type="submit" 
                                class="inline-flex items-center rounded-xl border border-rose-200 bg-rose-50/50 px-4 py-2.5 text-xs font-bold text-rose-600 hover:bg-rose-100 hover:border-rose-300 transition">
                            Batalkan Pesanan
                        </button>
                    </form>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>

        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
            
            
            <?php if (isset($component)) { $__componentOriginal3eed715fe9d3b5ad697d84d7da5fa0f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3eed715fe9d3b5ad697d84d7da5fa0f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.price-breakdown','data' => ['booking' => $booking]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('price-breakdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['booking' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($booking)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3eed715fe9d3b5ad697d84d7da5fa0f3)): ?>
<?php $attributes = $__attributesOriginal3eed715fe9d3b5ad697d84d7da5fa0f3; ?>
<?php unset($__attributesOriginal3eed715fe9d3b5ad697d84d7da5fa0f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3eed715fe9d3b5ad697d84d7da5fa0f3)): ?>
<?php $component = $__componentOriginal3eed715fe9d3b5ad697d84d7da5fa0f3; ?>
<?php unset($__componentOriginal3eed715fe9d3b5ad697d84d7da5fa0f3); ?>
<?php endif; ?>

            
            <div class="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div>
                        <h3 class="text-base font-bold text-slate-900">Riwayat Pembayaran</h3>
                        <p class="text-xs text-slate-400 mt-0.5">Daftar transaksi untuk pesanan ini.</p>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->invoice): ?>
                        <a href="<?php echo e(route('account.invoices.show', $booking->invoice)); ?>" 
                           class="text-xs font-bold text-emerald-600 hover:underline">
                            Lihat Tagihan &rarr;
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="space-y-2.5">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $booking->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginale58c9fff4e903a03544abf06ca1f4b12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale58c9fff4e903a03544abf06ca1f4b12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.payment-card','data' => ['payment' => $payment]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('payment-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['payment' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payment)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale58c9fff4e903a03544abf06ca1f4b12)): ?>
<?php $attributes = $__attributesOriginale58c9fff4e903a03544abf06ca1f4b12; ?>
<?php unset($__attributesOriginale58c9fff4e903a03544abf06ca1f4b12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale58c9fff4e903a03544abf06ca1f4b12)): ?>
<?php $component = $__componentOriginale58c9fff4e903a03544abf06ca1f4b12; ?>
<?php unset($__componentOriginale58c9fff4e903a03544abf06ca1f4b12); ?>
<?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <div class="rounded-2xl bg-slate-50 p-6 text-center text-xs text-slate-400 border border-slate-100">
                            Belum ada riwayat pembayaran yang tercatat.
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH /home/asepnrdn/projects/clients/travels/travel-agent/resources/views/account/booking-detail.blade.php ENDPATH**/ ?>