<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['tour']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['tour']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $avgRating = $tour->reviews_avg_rating ?? null;
    $reviewsCount = $tour->reviews_count ?? null;
?>

<a href="<?php echo e(route('tours.show', $tour->slug)); ?>" 
   class="group flex flex-col overflow-hidden rounded-3xl bg-white border border-slate-100 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50 hover:border-slate-200">
    
    
    <div class="relative aspect-[4/3] w-full overflow-hidden bg-slate-900">
        <img src="<?php echo e($tour->cover_image ? asset('storage/'.$tour->cover_image) : 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&q=80'); ?>"
             alt="<?php echo e($tour->name); ?>" 
             loading="lazy"
             class="h-full w-full object-cover transition duration-500 ease-out group-hover:scale-105">
        
        
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-transparent opacity-60"></div>

        
        <div class="absolute inset-x-3 top-3 flex items-center justify-between gap-2">
            <div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tour->is_featured): ?>
                    <span class="inline-flex items-center gap-1 rounded-full bg-emerald-500/90 backdrop-blur-md px-2.5 py-1 text-[11px] font-bold text-white shadow-sm border border-emerald-400/30">
                        <svg class="h-3 w-3 text-amber-300" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                        </svg>
                        Unggulan
                    </span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <span class="inline-flex items-center rounded-full bg-slate-950/70 backdrop-blur-md px-3 py-1 text-[11px] font-semibold text-white border border-white/15">
                <?php echo e($tour->duration_days); ?>H <?php echo e($tour->duration_nights); ?>M
            </span>
        </div>
    </div>

    
    <div class="flex flex-1 flex-col p-5">
        
        
        <p class="text-xs font-bold uppercase tracking-wider text-emerald-600">
            <?php echo e($tour->destination->name ?? 'Destinasi'); ?>

        </p>

        
        <h3 class="mt-1.5 line-clamp-2 text-lg font-bold text-slate-900 group-hover:text-emerald-600 transition duration-200">
            <?php echo e($tour->name); ?>

        </h3>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($avgRating): ?>
            <div class="mt-2.5 flex items-center gap-1.5">
                <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => $avgRating,'count' => $reviewsCount,'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($avgRating),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reviewsCount),'size' => 'sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
            </div>
        <?php else: ?>
            <div class="mt-2.5 text-[11px] font-medium text-slate-400">
                Belum ada ulasan
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="mt-auto pt-5 flex items-end justify-between border-t border-slate-100">
            <div>
                <span class="block text-[11px] font-medium text-slate-400 uppercase tracking-wide">Mulai Dari</span>
                <p class="text-lg font-extrabold text-slate-900">
                    Rp <?php echo e(number_format($tour->price_adult, 0, ',', '.')); ?>

                </p>
            </div>

            <span class="inline-flex items-center gap-1 rounded-xl bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 border border-slate-200/80 group-hover:bg-emerald-600 group-hover:text-white group-hover:border-emerald-600 transition duration-200">
                Detail
                <svg class="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                </svg>
            </span>
        </div>
    </div>
</a><?php /**PATH /home/asepnrdn/projects/clients/travels/travel-agent/resources/views/components/tour-card.blade.php ENDPATH**/ ?>