<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $map = [
        'pending' => 'bg-amber-100 text-amber-700',
        'confirmed' => 'bg-primary-100 text-primary-800',
        'completed' => 'bg-emerald-100 text-emerald-700',
        'cancelled' => 'bg-red-100 text-red-700',
        'open' => 'bg-emerald-100 text-emerald-700',
        'full' => 'bg-amber-100 text-amber-700',
        'closed' => 'bg-slate-200 text-slate-600',
        'paid' => 'bg-emerald-100 text-emerald-700',
        'partially_paid' => 'bg-amber-100 text-amber-700',
        'unpaid' => 'bg-red-100 text-red-700',
        'failed' => 'bg-red-100 text-red-700',
        'expired' => 'bg-slate-200 text-slate-600',
        'refunded' => 'bg-slate-200 text-slate-600',
    ];
    $classes = $map[$status] ?? 'bg-slate-100 text-slate-600';
?>
<span <?php echo e($attributes->merge(['class' => "badge $classes"])); ?>>
    <?php echo e(ucfirst(str_replace('_', ' ', $status))); ?>

</span>
<?php /**PATH /home/asepnrdn/projects/clients/travels/travel-agent/resources/views/components/status-badge.blade.php ENDPATH**/ ?>