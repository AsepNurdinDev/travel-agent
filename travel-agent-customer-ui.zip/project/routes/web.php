<?php

use App\Http\Controllers\Account\BookingController as AccountBookingController;
use App\Http\Controllers\Account\DashboardController as AccountDashboardController;
use App\Http\Controllers\Account\InvoiceController as AccountInvoiceController;
use App\Http\Controllers\Account\ProfileController as AccountProfileController;
use App\Http\Controllers\Account\ReviewController as AccountReviewController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\DestinationController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TourPackageController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public website
|--------------------------------------------------------------------------
*/

Route::get('/', HomeController::class)->name('home');

Route::get('/destinations', [DestinationController::class, 'index'])->name('destinations.index');
Route::get('/destinations/{destination:slug}', [DestinationController::class, 'show'])->name('destinations.show');

Route::get('/tours', [TourPackageController::class, 'index'])->name('tours.index');
Route::get('/tours/{tourPackage:slug}', [TourPackageController::class, 'show'])->name('tours.show');

Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/{blogPost:slug}', [BlogController::class, 'show'])->name('blog.show');

Route::get('/gallery', [GalleryController::class, 'index'])->name('gallery.index');

Route::get('/about', [PageController::class, 'about'])->name('about');

Route::get('/contact', [ContactController::class, 'index'])->name('contact.index');
Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');

/*
|--------------------------------------------------------------------------
| Existing Breeze profile routes — untouched.
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

/*
|--------------------------------------------------------------------------
| Booking flow (requires an authenticated + verified customer)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified'])->prefix('booking')->name('booking.')->group(function () {
    Route::post('/estimate', [BookingController::class, 'estimate'])->name('estimate');

    Route::get('/{availability}', [BookingController::class, 'create'])
        ->whereNumber('availability')->name('create');
    Route::post('/{availability}', [BookingController::class, 'store'])
        ->whereNumber('availability')->name('store');

    Route::get('/{booking}/checkout', [BookingController::class, 'checkout'])
        ->whereNumber('booking')->name('checkout');
    Route::post('/{booking}/checkout', [BookingController::class, 'pay'])
        ->whereNumber('booking')->name('pay');
    Route::get('/{booking}/success', [BookingController::class, 'success'])
        ->whereNumber('booking')->name('success');
});

/*
|--------------------------------------------------------------------------
| Customer account portal
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified'])->prefix('account')->name('account.')->group(function () {
    Route::get('/', AccountDashboardController::class)->name('dashboard');

    Route::get('/bookings', [AccountBookingController::class, 'index'])->name('bookings');
    Route::get('/bookings/{booking}', [AccountBookingController::class, 'show'])
        ->whereNumber('booking')->name('bookings.show');
    Route::post('/bookings/{booking}/cancel', [AccountBookingController::class, 'cancel'])
        ->whereNumber('booking')->name('bookings.cancel');

    Route::get('/invoices', [AccountInvoiceController::class, 'index'])->name('invoices');
    Route::get('/invoices/{invoice}', [AccountInvoiceController::class, 'show'])
        ->whereNumber('invoice')->name('invoices.show');

    Route::get('/profile', [AccountProfileController::class, 'edit'])->name('profile');
    Route::patch('/profile', [AccountProfileController::class, 'update'])->name('profile.update');

    Route::get('/password', [AccountProfileController::class, 'password'])->name('password');

    Route::get('/reviews', [AccountReviewController::class, 'index'])->name('reviews');
    Route::post('/reviews', [AccountReviewController::class, 'store'])->name('reviews.store');
});

/*
|--------------------------------------------------------------------------
| /dashboard now points into the customer portal instead of the Breeze
| placeholder dashboard (see section 22 of the brief).
|--------------------------------------------------------------------------
*/

Route::get('/dashboard', function () {
    return redirect()->route('account.dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

require __DIR__.'/auth.php';
