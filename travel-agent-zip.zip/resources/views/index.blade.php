<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nusantara Travel Agent</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 text-white min-h-screen flex items-center justify-center font-sans">

    <div class="max-w-xl text-center px-6 py-12 bg-slate-800/80 rounded-2xl border border-slate-700 shadow-2xl backdrop-blur-sm">
        <!-- Tagline Badge -->
        <span class="px-3 py-1 text-xs font-semibold uppercase tracking-widest text-teal-400 bg-teal-950 rounded-full border border-teal-800">
            Official Travel Agent
        </span>

        <!-- Title & Subtitle -->
        <h1 class="text-3xl md:text-5xl font-extrabold mt-6 mb-4 leading-tight">
            Nusantara <span class="text-amber-400">Travel</span>
        </h1>
        <p class="text-slate-300 text-sm md:text-base mb-8">
            Website Customer Travel Agent sedang dalam tahap pengembangan.
        </p>

        <!-- Navigation Buttons -->
        <div class="flex flex-wrap justify-center gap-4">
            {{-- Menggunakan Route Auth Breeze yang aman --}}
            @if (Route::has('login'))
                @auth
                    <a href="{{ url('/dashboard') }}" class="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg text-sm transition">
                        Dashboard Saya
                    </a>
                @else
                    <a href="{{ route('login') }}" class="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold rounded-lg text-sm transition">
                        Masuk / Login
                    </a>
                    @if (Route::has('register'))
                        <a href="{{ route('register') }}" class="px-6 py-2.5 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded-lg text-sm transition">
                            Daftar Akun
                        </a>
                    @endif
                @endauth
            @endif
        </div>
    </div>

</body>
</html>