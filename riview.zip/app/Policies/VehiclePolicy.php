<?php

namespace App\Policies;

use App\Models\Vehicle;
use App\Models\User;

class VehiclePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('vehicles.view');
    }

    public function view(User $user, Vehicle $vehicle): bool
    {
        return $user->can('vehicles.view');
    }

    public function create(User $user): bool
    {
        return $user->can('vehicles.create');
    }

    public function update(User $user, Vehicle $vehicle): bool
    {
        return $user->can('vehicles.update');
    }

    public function delete(User $user, Vehicle $vehicle): bool
    {
        return $user->can('vehicles.delete');
    }

    public function restore(User $user, Vehicle $vehicle): bool
    {
        return $user->can('vehicles.update');
    }

    public function forceDelete(User $user, Vehicle $vehicle): bool
    {
        return $user->can('vehicles.delete') && $user->hasRole('super_admin');
    }
}
